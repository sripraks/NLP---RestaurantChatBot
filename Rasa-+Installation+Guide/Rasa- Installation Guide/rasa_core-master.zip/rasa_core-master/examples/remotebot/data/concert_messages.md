## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:thankyou
- thanks
- thank you
- thank you very much
- nice

## intent:search_concerts
- I am looking for a concert
- where can I find a concert
- Whats the next event

## intent:search_venues
- what is a good venue
- where is the best venue
- show me a nice venue
- how about a venue

## intent:compare_reviews
- how do these compare
- what are the reviews
- what do people say about them
- which one is better

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
