.. _slot_types:

Slot Types
==========

The Slot base class
--------------------

.. autoclass:: rasa_core.slots.Slot

   .. automethod:: feature_dimensionality

   .. automethod:: as_feature

