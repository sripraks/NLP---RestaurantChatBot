.. _section_docker:

Running in Docker
=================

Rasa NLU docker images are provided for different backends:


.. code-block:: bash

    docker run rasa/rasa_nlu:latest-full -p5000:5000
